const countdownBanner = document.querySelector('#countdown-banner');

if (countdownBanner) {

    const launchDate = new Date(2025, 9, 1); // 1 октября 2025

    function updateCounter() {
        const now = new Date();
        const timeDiff = launchDate.getTime() - now.getTime();
        const daysLeft = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));

        const counterElement = document.querySelector('#countdown-banner .number');
        const currentValue = parseInt(counterElement.textContent);

        if (daysLeft !== currentValue) {
            counterElement.style.animation = 'pulse 0.3s ease-in-out';
            counterElement.textContent = Math.max(0, daysLeft);

            setTimeout(() => {
                counterElement.style.animation = '';
            }, 300);
        }

        if (daysLeft <= 0) {
            counterElement.textContent = '0';
            document.querySelector('#countdown-banner .text').textContent =
                'Электронная очередь на МАПП Верхний Ларс запущена!';
        }
    }

    updateCounter();

    setInterval(updateCounter, 30 * 1000);

}