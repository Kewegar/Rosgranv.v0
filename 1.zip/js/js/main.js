import {iosVhFix} from './utils/ios-vh-fix.js';
import {initModals} from './modules/modals/init-modals.js';
import {initCustomSelect} from './modules/form/init-custom-select.js';
import {initFormValidate} from './modules/form/init-form-validate.js';
import {initVideo} from './modules/init-video.js';
import {initLike} from './modules/init-like.js';
import {showBlock} from './modules/show-block.js';
import {setTopHeaderSubmenu} from './modules/set-top-header-submenu.js';
import {initHeader} from './modules/init-header.js';
import {initTabs} from './modules/init-tabs.js';
import {setPaddingFirstBlock} from './modules/set-padding-first-block.js';
import {initIntroSliders} from './modules/init-intro-sliders.js';
import {initTabControls} from './modules/init-tab-controls.js';
import {initButtonsFilterNews} from './modules/init-buttons-filter-news.js';
import {initAccordions} from './modules/accordion/init-accordion.js';
// import {initMap} from './modules/map/init-map.js';
import {initInformationTable} from './modules/init-information-table.js';
import {initSameNewsSlider} from './modules/init-same-news-slider.js';
import {initFilters} from './modules/filters/init-filters.js';
import {initAccordionIcon} from './modules/init-accordion-icon.js';
import {showSearchHeader} from './modules/show-search-header.js';
import {initMapContacts} from './modules/map/init-map-contacts.js';
import {initMoveTo} from './modules/init-moveto.js';
import {initSwiperCurrentInfo} from './modules/init-swiper-current-info.js';
import {initSwiperSmall} from './modules/init-swiper-small.js';
import {initMenu} from './modules/init-menu.js';
import {screenHeight} from './modules/init-screen-height.js';
import {initPseudoSelect} from './modules/init-pseudo-select.js';
import {initPhotogalleryNewsSlider} from './modules/init-photogallery-news-slider.js';
import {initLoadFiles} from './modules/form/init-load-files.js';
import {initModalPhotosSlider} from './modules/init-modal-photos-slider.js';
// ---------------------------------

window.addEventListener('DOMContentLoaded', () => {

  // Utils
  // ---------------------------------

  iosVhFix();

  // Modules
  initVideo();
  initLike();
  showBlock();
  setTopHeaderSubmenu();
  initHeader();
  setPaddingFirstBlock();
  initIntroSliders();
  initButtonsFilterNews();
  initInformationTable();
  initSameNewsSlider();
  showSearchHeader();
  initMenu();
  screenHeight();
  initPhotogalleryNewsSlider();
  initLoadFiles();
  initModalPhotosSlider();

  // все скрипты должны быть в обработчике 'DOMContentLoaded', но не все в 'load'
  // в load следует добавить скрипты, не участвующие в работе первого экрана
  window.addEventListener('load', () => {
    initModals();
    initCustomSelect();
    initFormValidate();
    initTabs();
    initTabControls();
    initAccordions();
    initPseudoSelect();
    initMoveTo();
    // initFilters();
    initAccordionIcon();
    // initMap();
    initMapContacts();
    initSwiperCurrentInfo();
    initSwiperSmall();
  });
});

// ---------------------------------

// ❗❗❗ обязательно установите плагины eslint, stylelint, editorconfig в редактор кода.

// привязывайте js не на классы, а на дата атрибуты (data-validate)

// вместо модификаторов .block--active используем утилитарные классы
// .is-active || .is-open || .is-invalid и прочие (обязателен нейминг в два слова)
// .select.select--opened ❌ ---> [data-select].is-open ✅

// выносим все в дата атрибуты
// url до иконок пинов карты, настройки автопрокрутки слайдера, url к json и т.д.

// для адаптивного JS используейтся matchMedia и addListener
// const breakpoint = window.matchMedia(`(min-width:1024px)`);
// const breakpointChecker = () => {
//   if (breakpoint.matches) {
//   } else {
//   }
// };
// breakpoint.addListener(breakpointChecker);
// breakpointChecker();

// используйте .closest(el)
